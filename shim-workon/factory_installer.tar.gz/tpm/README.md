One of the script file in this folder will be installed to
`/usr/share/factory_installer/tpm/` by `chromeos-base/factory_installer` ebuild
as name `tpm_utils.sh`.

# Interfaces
TODO(stimim)
